from app import create_app
import os
import signal

app = create_app()

def signal_handler(signal_received, frame):
    print("SIGINT or SIGTERM detected. Exiting gracefully...")
    os._exit(0)

if __name__ == "__main__":
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    app.run(host="0.0.0.0", port=5000)